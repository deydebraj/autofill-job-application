const {chromium} = require('playwright');
const path = require('node:path');
const assert = require('node:assert/strict');
(async () => {
  const browser = await chromium.launch({headless:true, args:['--no-sandbox']});
  const page = await browser.newPage();
  await page.route('https://jobs.ashbyhq.com/test', route => route.fulfill({contentType:'text/html', body:`<form>
    <label for="name">Full name *</label><input id="name">
    <label>Email<input type="email" id="email" value="existing@example.com"></label>
    <label>LinkedIn URL<input id="linkedin"></label>
    <label>Phone number<input id="phone"></label>
    <label>Why us?<textarea id="why"></textarea></label>
    <label>Country<select id="country"><option value="">Choose</option><option value="US">United States</option></select></label>
    <label>Location<input id="location" role="combobox"></label>
    <label>Resume<input type="file" id="resume"></label>
    <label>First name<input style="display:none" id="hidden"></label>
    <label>Last name<input disabled id="disabled"></label>
    <label>Agree<input type="checkbox" id="agree"></label>
    <button type="submit">Submit</button></form>`}));
  await page.goto('https://jobs.ashbyhq.com/test');
  await page.addScriptTag({path:path.resolve(__dirname,'../fields.js')});
  await page.addScriptTag({path:path.resolve(__dirname,'../engine.js')});
  await page.evaluate(() => {
    window.events=[]; window.submitted=false;
    document.querySelector('form').addEventListener('submit',e=>{e.preventDefault();window.submitted=true});
    document.querySelector('#name').addEventListener('input',e=>window.events.push(e.target.value));
  });
  const rows=await page.evaluate(()=>ashbyHelper.scan({firstName:'Test',lastName:'Applicant',email:'new@example.com',phone:'1234567890',linkedin:'https://linkedin.com/in/test',location:'Seattle',custom:[{question:'Why us?',answer:'My saved answer'},{question:'Country',answer:'United States'}]}));
  assert.equal(rows.filter(r=>!r.reason).length,5);
  assert.equal(rows.find(r=>r.label==='Email').reason,'Already filled — preserved');
  await page.fill('#phone','user changed this');
  const result=await page.evaluate(ids=>ashbyHelper.fill(ids),rows.filter(r=>!r.reason).map(r=>r.id));
  assert.deepEqual(result,{filled:4,skipped:1});
  assert.equal(await page.inputValue('#name'),'Test Applicant');
  assert.equal(await page.inputValue('#email'),'existing@example.com');
  assert.equal(await page.inputValue('#phone'),'user changed this');
  assert.equal(await page.inputValue('#country'),'US');
  assert.equal(await page.inputValue('#location'),'');
  assert.equal(await page.isChecked('#agree'),false);
  assert.deepEqual(await page.evaluate(()=>events),['Test Applicant']);
  assert.equal(await page.evaluate(()=>submitted),false);
  await page.evaluate(()=>ashbyHelper.scan({}));
  await page.evaluate(()=>history.pushState({},'', '/changed'));
  await assert.rejects(()=>page.evaluate(()=>ashbyHelper.fill([])),/Page changed/);
  await browser.close();
  console.log('PASS: matching, native select, input events, existing answers, preview changes, manual fields, navigation guard, no submission');
})().catch(e=>{console.error(e);process.exit(1)});
