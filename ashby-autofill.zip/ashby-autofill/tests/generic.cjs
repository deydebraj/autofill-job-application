const {JSDOM}=require('jsdom'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),source=f=>fs.readFileSync(path.join(root,f),'utf8');
function setup(){
 const dom=new JSDOM('<form></form>',{url:'https://jobs.ashbyhq.com/example/job/application',runScripts:'outside-only'});
 const w=dom.window,d=w.document;w.HTMLElement.prototype.getClientRects=()=>[{}];
 for(const f of ['fields.js','engine.js'])w.eval(source(f));
 return {w,d};
}
const {w}=setup();let count=0;
for(const f of w.ashbyExtraFields){
 assert.equal(f.scope,undefined);
 for(const q of f.questions){
  const {w,d}=setup();const label=d.createElement('label');label.textContent=q+' *';label.append(d.createElement('input'));d.querySelector('form').append(label);
  let rows=w.ashbyHelper.scan({[f.key]:'ANSWER'});assert.equal(rows[0].answer,'ANSWER',q);
  w.history.pushState({},'', '/another/job/application');rows=w.ashbyHelper.scan({[f.key]:'ANSWER'});assert.equal(rows[0].answer,'ANSWER');count++;
 }
}
const {w:app,d}=setup();
app.eval(source('fields.js'));app.eval(source('engine.js'));
d.querySelector('form').innerHTML=`<label>Name<input id="name"></label><label>Email<input id="email" value="kept@example.com"></label><label>Why are you interested in this role?<textarea id="why"></textarea></label>
<label>How many years of experience do you have with React?<input id="react"></label><label>Are you legally authorized to work in Canada?<input id="canada"></label><label>What are your pronouns?<input></label>
<fieldset><legend>Are you willing to relocate?</legend><label><input type="radio" name="relocate" id="yes">Yes</label><label><input type="radio" name="relocate">No</label></fieldset>
<div class="ashby-application-form-field-entry"><label class="ashby-application-form-question-title">Are you legally authorized to work in the United States?</label><div class="ashby-application-form-input-yesno"><button data-option="yes" aria-pressed="false">Yes</button><button data-option="no" aria-pressed="false">No</button><input type="checkbox"></div></div>`;
let submits=0;d.querySelector('form').addEventListener('submit',e=>{submits++;e.preventDefault()});
d.querySelector('form').addEventListener('click',e=>{if(e.target.matches('button[data-option]'))e.target.setAttribute('aria-pressed','true')});
const profile={firstName:'Test',lastName:'Applicant',email:'new@example.com',applicationMotivation:'Generic answer',yearsReact:'4',workAuthorizationUS:'Yes',willingRelocate:'Yes',pronouns:'they/them',custom:[{question:'Why are you interested in this role?',answer:'Old scoped answer',scope:'example'}]};
let rows=app.ashbyHelper.scan(profile);
assert.equal(rows.find(r=>r.label.startsWith('Why')).answer,'Generic answer');
assert.equal(rows.find(r=>r.label.includes('Canada')).reason,'No saved answer');
assert.equal(rows.find(r=>r.label.includes('pronouns')).optional,true);
d.getElementById('why').value='Changed after preview';
let result=app.ashbyHelper.fill(rows.filter(r=>!r.reason && !r.optional).map(r=>r.id));
assert.equal(result.filled,4);assert.equal(result.skipped,1);assert.equal(submits,0);
assert.equal(d.getElementById('email').value,'kept@example.com');assert.equal(d.getElementById('why').value,'Changed after preview');assert.equal(d.getElementById('yes').checked,true);
console.log(`PASS: ${count} generic mappings across sites, repeat injection, legacy scoped answer isolation, country isolation, optional fields, radio/Yes-No controls, preserved values, no submission.`);
(async()=>{
 const dom=new JSDOM(source('options.html'),{url:'https://extension.test',runScripts:'outside-only'});let saved;
 dom.window.chrome={storage:{local:{get:async()=>({profile:{firstName:'Kept',yearsReact:'5',deprecatedAnswer:'Old text',custom:[{question:'Scoped',answer:'Old',scope:'example'},{question:'Generic',answer:'Keep',aliases:['Equivalent']}]}}),set:async x=>{saved=x.profile}}}};
 dom.window.eval(source('fields.js'));dom.window.eval(source('options.js'));await new Promise(r=>setImmediate(r));
 const d=dom.window.document;assert.equal(d.getElementById('firstName').value,'Kept');assert.equal(d.getElementById('yearsReact').value,'5');assert.equal(d.querySelectorAll('.answer').length,1);assert.equal(d.querySelector('.scope'),null);assert.equal(d.getElementById('applicationMotivation').value,'');
 d.getElementById('form').dispatchEvent(new dom.window.Event('submit',{cancelable:true}));await new Promise(r=>setImmediate(r));
 assert.equal(saved.firstName,'Kept');assert.equal(saved.deprecatedAnswer,undefined);assert.equal(saved.custom.length,1);assert.equal(saved.custom[0].aliases[0],'Equivalent');assert.equal(saved.custom[0].scope,undefined);
 console.log('PASS: generic settings UI, retained common details, discarded legacy scoped answers, blank replacement answers, custom-variant persistence.');
})().catch(e=>{console.error(e);process.exitCode=1});
